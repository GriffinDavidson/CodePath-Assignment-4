//
//  HomeTableViewController.swift
//  Twitter
//
//  Created by Griffin Davidson on 3/5/22.
//  Copyright © 2022 Dan. All rights reserved.
//

import UIKit
import AlamofireImage

class HomeTableViewController: UITableViewController
{
    
    private var tweets = [NSDictionary]()
    private var numberOfTweets: Int!
    
    let viewRefreshControl = UIRefreshControl()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        loadTweets()
        
        // configures pull-to-refresh
        viewRefreshControl.addTarget(self, action: #selector(loadTweets), for: .valueChanged)
        tableView.refreshControl = viewRefreshControl
        
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 250
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("View Did Appear!")
        
        self.loadTweets()
        self.tableView.reloadData()
    }
    
    // Calls and loads first set of tweets
    @objc func loadTweets()
    {
        numberOfTweets = 20
        let resourceURL = "https://api.twitter.com/1.1/statuses/home_timeline.json"
        let parameters = ["count": numberOfTweets!]
        
        TwitterAPICaller.client?.getDictionariesRequest(url: resourceURL,
                                                      parameters: parameters,
                                                      success:
            { (gatheredTweets: [NSDictionary]) in
                self.tweets.removeAll()
                for tweet in gatheredTweets
                {
                    self.tweets.append(tweet)
                }
            
            self.tableView.reloadData()
            
            // stops the refresh icon from displaying permanently
            self.viewRefreshControl.endRefreshing()
            
            },
            failure:
            { (Error) in
                print("Failed to recieve tweets")
                print("\nTWEET FETCH ERROR: \(Error.localizedDescription)\n")
            })
    }
    
    // infinte-scrolling function, very similar to loadTweets()
    func loadMoreTweets()
    {
        let url = "https://api.twitter.com/1.1/statuses/home_timeline.json"
        
        numberOfTweets += 20
        
        let parameters = ["count": numberOfTweets!]
        
        TwitterAPICaller.client?.getDictionariesRequest(url: url,
                                                      parameters: parameters,
                                                      success:
            { (gatheredTweets: [NSDictionary]) in
                self.tweets.removeAll()
                for tweet in gatheredTweets
                {
                    self.tweets.append(tweet)
                }
            
            self.tableView.reloadData()
            
            },
            failure:
            { (Error) in
                print("Failed to recieve tweets")
                print("\nTWEET FETCH ERROR: \(Error.localizedDescription)\n")
            })
    }
    
    // enables infinite scrolling
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        if indexPath.row + 1 == tweets.count
        {
            loadMoreTweets()
        }
    }
    
    // logout button at top left
    @IBAction func logoutButton(_ sender: Any)
    {
        TwitterAPICaller.client?.logout()
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        self.dismiss(animated: true, completion: nil)
    }
    
    // configures table cell for each tweet
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TweetTableViewCell", for: indexPath) as! TweetTableViewCell
        
        let dictionary = tweets[indexPath.row]["user"] as! NSDictionary
        let name = dictionary.value(forKey: "name") as! String
        let handle = dictionary.value(forKey: "screen_name") as! String
        
        cell.tweetBodyLabel.text = (tweets[indexPath.row]["text"] as! String)
        cell.tweetUsernameLabel.text = name
        cell.tweetHandleLabel.text = "@\(handle)"
        
        let imageURL = URL(string: (dictionary.value(forKey: "profile_image_url") as! String))
        let data = try? Data(contentsOf: imageURL!)
        
        if let image = data
        {
            cell.tweetProfileImage.image = UIImage(data: image)
        }
        
        cell.setFavorite(tweets[indexPath.row]["favorited"] as! Bool)
        cell.tweetID = tweets[indexPath.row]["id"] as! Int
        cell.setRetweet(tweets[indexPath.row]["retweeted"] as! Bool)
        
        return cell
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return tweets.count
    }
}
