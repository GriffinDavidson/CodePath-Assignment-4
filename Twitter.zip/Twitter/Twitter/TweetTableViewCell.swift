//
//  TweetTableViewCell.swift
//  Twitter
//
//  Created by Griffin Davidson on 3/5/22.
//  Copyright © 2022 Dan. All rights reserved.
//

import UIKit

class TweetTableViewCell: UITableViewCell {
    
    @IBOutlet weak var tweetBodyLabel: UILabel!
    @IBOutlet weak var tweetHandleLabel: UILabel!
    @IBOutlet weak var tweetUsernameLabel: UILabel!
    @IBOutlet weak var tweetProfileImage: UIImageView!
    @IBOutlet weak var tweetFavoriteButton: UIButton!
    @IBOutlet weak var tweetRetweetButton: UIButton!
    
    var favorite: Bool = false
    var tweetID: Int = -1
    var retweet: Bool = false
    
    @IBAction func favorite(_ sender: Any)
    {
        let toBeFavorited = !favorite
        if (toBeFavorited)
        {
            TwitterAPICaller.client?.favoriteTweet(id: tweetID, success: {
                self.setFavorite(true)
            }, failure: { (error) in
                    print("Failed to favorite tweet/nERROR: \(error)")
            })
        }
        else
        {
            TwitterAPICaller.client?.unFavoriteTweet(id: tweetID, success: {
                self.setFavorite(false)
            }, failure: { (error) in
                print("Failed to favorite tweet/nERROR: \(error)")
            })
        }
    }
    
    @IBAction func retweet(_ sender: Any)
    {
        TwitterAPICaller.client?.retweetTweet(id: tweetID, success: {
            self.setRetweet(true)
        }, failure: { (error) in
            print("Failed to retweet tweet\nERROR: \(error)")
        })
    }
    
    func setFavorite(_ isFavorited: Bool)
    {
        favorite = isFavorited
        if (favorite)
        {
            tweetFavoriteButton.setImage(UIImage(systemName: "heart.fill"), for: UIControl.State.normal)
        }
        else
        {
            tweetFavoriteButton.setImage(UIImage(systemName: "heart"), for: UIControl.State.normal)
        }
    }
    
    func setRetweet(_ isReTweeted: Bool)
    {
        retweet = isReTweeted
        if (retweet)
        {
            let image = UIImage(systemName: "arrow.2.squarepath")?.withTintColor(.systemGreen, renderingMode: .alwaysOriginal)
            tweetRetweetButton.setImage(image, for: UIControl.State.normal)
            tweetRetweetButton.isEnabled = false
        }
        else
        {
            let image = UIImage(systemName: "arrow.2.squarepath")?.withTintColor(.systemGray, renderingMode: .alwaysOriginal)
            tweetRetweetButton.setImage(image, for: UIControl.State.normal)
            tweetRetweetButton.isEnabled = true
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
